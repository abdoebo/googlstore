import React from 'react';
import { Download } from 'lucide-react';
import { downloadMedia, generateFileName } from '../utils/download';

interface DownloadButtonProps {
  url: string;
  type: 'video' | 'image';
  username: string;
}

export default function DownloadButton({ url, type, username }: DownloadButtonProps) {
  const handleDownload = async () => {
    try {
      const filename = generateFileName(username, type);
      await downloadMedia(url, filename);
    } catch (error) {
      // In a production app, we'd want to show a proper error notification
      console.error('Download failed:', error);
    }
  };

  return (
    <button
      onClick={handleDownload}
      className="flex items-center space-x-1 hover:text-purple-600 transition-colors"
      title="Download media"
    >
      <Download className="h-6 w-6" />
    </button>
  );
}