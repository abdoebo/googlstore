import React from 'react';
import { Search, Bell, MessageCircle, Settings } from 'lucide-react';

export default function Header() {
  return (
    <header className="fixed top-0 w-full bg-gradient-to-r from-purple-600 via-pink-500 to-orange-500 text-white z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Horizon</h1>
        
        <div className="flex items-center space-x-6">
          <div className="relative">
            <input
              type="search"
              placeholder="Search..."
              className="bg-white/20 rounded-full py-2 px-4 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-white/50"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4" />
          </div>
          
          <nav className="flex items-center space-x-4">
            <Bell className="h-6 w-6 cursor-pointer hover:text-purple-200 transition-colors" />
            <MessageCircle className="h-6 w-6 cursor-pointer hover:text-purple-200 transition-colors" />
            <Settings className="h-6 w-6 cursor-pointer hover:text-purple-200 transition-colors" />
          </nav>
        </div>
      </div>
    </header>
  );
}