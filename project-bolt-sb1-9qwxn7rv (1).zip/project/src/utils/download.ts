export async function downloadMedia(url: string, filename: string): Promise<void> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(blobUrl);
  } catch (error) {
    console.error('Download failed:', error);
    throw new Error('Failed to download media');
  }
}

export function generateFileName(username: string, type: 'video' | 'image'): string {
  const timestamp = new Date().getTime();
  const extension = type === 'video' ? 'mp4' : 'jpg';
  return `horizon_${username}_${timestamp}.${extension}`;
}