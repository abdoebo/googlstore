import React from 'react';
import Header from './components/Header';
import FeedItem from './components/FeedItem';

const SAMPLE_POSTS = [
  {
    username: 'creative_mind',
    content: {
      type: 'image' as const,
      url: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba',
      caption: 'Exploring new horizons! 🌅 #AI #Future'
    },
    aiTags: ['Trending', 'Creative', 'Inspiring'],
    likes: 1234,
    comments: 89
  },
  {
    username: 'tech_innovator',
    content: {
      type: 'image' as const,
      url: 'https://images.unsplash.com/photo-1682687221038-404670f05144',
      caption: 'The future is now! 🚀 #Innovation #Technology'
    },
    aiTags: ['Tech', 'Innovation', 'Trending'],
    likes: 2341,
    comments: 156
  }
];

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 pt-20 pb-16 max-w-2xl">
        <div className="space-y-6">
          {SAMPLE_POSTS.map((post, index) => (
            <FeedItem key={index} post={post} />
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;