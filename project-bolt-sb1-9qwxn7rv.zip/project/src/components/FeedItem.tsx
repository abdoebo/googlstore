import React from 'react';
import { Heart, MessageCircle, Share2, Brain } from 'lucide-react';

interface FeedItemProps {
  post: {
    username: string;
    content: {
      type: 'video' | 'image';
      url: string;
      caption: string;
    };
    aiTags: string[];
    likes: number;
    comments: number;
  };
}

export default function FeedItem({ post }: FeedItemProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
      <div className="p-4">
        <div className="flex items-center mb-3">
          <img
            src={`https://api.dicebear.com/7.x/avatars/svg?seed=${post.username}`}
            alt={post.username}
            className="w-10 h-10 rounded-full"
          />
          <span className="ml-3 font-semibold">{post.username}</span>
        </div>
      </div>

      <div className="relative aspect-[9/16] bg-black">
        {post.content.type === 'video' ? (
          <video
            src={post.content.url}
            className="w-full h-full object-cover"
            controls
            loop
          />
        ) : (
          <img
            src={post.content.url}
            alt={post.content.caption}
            className="w-full h-full object-cover"
          />
        )}
      </div>

      <div className="p-4">
        <div className="flex justify-between mb-4">
          <div className="flex space-x-4">
            <button className="flex items-center space-x-1">
              <Heart className="h-6 w-6" />
              <span>{post.likes}</span>
            </button>
            <button className="flex items-center space-x-1">
              <MessageCircle className="h-6 w-6" />
              <span>{post.comments}</span>
            </button>
            <button>
              <Share2 className="h-6 w-6" />
            </button>
          </div>
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-500" />
            <div className="flex flex-wrap gap-2">
              {post.aiTags.map((tag, index) => (
                <span
                  key={index}
                  className="text-xs bg-purple-100 text-purple-600 px-2 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
        <p className="text-gray-800">{post.content.caption}</p>
      </div>
    </div>
  );
}