export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
}

export interface Post {
  id: string;
  userId: string;
  content: {
    type: 'video' | 'image';
    url: string;
    caption: string;
  };
  likes: number;
  comments: number;
  shares: number;
  aiTags: string[];
  createdAt: string;
}

export interface AIRecommendation {
  contentType: string;
  score: number;
  reason: string;
  mentalHealthImpact: number;
}